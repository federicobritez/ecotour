CREATE DATABASE  IF NOT EXISTS `ecoturismo` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `ecoturismo`;
-- MySQL dump 10.13  Distrib 5.5.50, for debian-linux-gnu (i686)
--
-- Host: localhost    Database: ecoturismo
-- ------------------------------------------------------
-- Server version	5.5.50-0+deb8u1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `horarios_reserva`
--

DROP TABLE IF EXISTS `horarios_reserva`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `horarios_reserva` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `horarios_servicio_id` int(11) NOT NULL,
  `reserva_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_horarios_reserva_horarios_servicio1_idx` (`horarios_servicio_id`),
  KEY `fk_horarios_reserva_reserva1_idx` (`reserva_id`),
  CONSTRAINT `fk_horarios_reserva_horarios_servicio1` FOREIGN KEY (`horarios_servicio_id`) REFERENCES `horarios_servicio` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  CONSTRAINT `fk_horarios_reserva_reserva1` FOREIGN KEY (`reserva_id`) REFERENCES `reserva` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8 COMMENT='Grupo de servicios a reservar por el cliente\n';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `horarios_reserva`
--

LOCK TABLES `horarios_reserva` WRITE;
/*!40000 ALTER TABLE `horarios_reserva` DISABLE KEYS */;
INSERT INTO `horarios_reserva` VALUES (1,4,52),(2,7,54),(3,4,59),(4,7,61),(5,4,78),(6,7,80),(7,4,86),(8,7,88),(10,8,23),(11,2,25),(14,13,32),(15,4,34),(16,13,35);
/*!40000 ALTER TABLE `horarios_reserva` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-10-02 22:30:32
